<?php
$pagine = [
    [
        'slug' => 'index',
        'titolo' => 'Home Page',
        'contenuto' => 'Benvenuto nella pagina principale!'
    ],
    [
        'slug' => 'chi-siamo',
        'titolo' => 'Chi Siamo',
        'contenuto' => 'Siamo un team di sviluppatori appassionati.'
    ],
    [
        'slug' => 'servizi',
        'titolo' => 'I nostri servizi',
        'contenuto' => 'Offriamo sviluppo web, consulenza e formazione.'
    ],
    [
        'slug' => 'portfolio',
        'titolo' => 'Portfolio',
        'contenuto' => 'Guarda alcuni dei nostri progetti realizzati.'
    ],
    [
        'slug' => 'contatti',
        'titolo' => 'Contattaci',
        'contenuto' => 'Scrivici per un preventivo gratuito!'
    ],
];
